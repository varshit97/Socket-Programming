# Socket-Programming

Question 1
Go to the directory 1/ and run "make".
On client machine run "socat - udp-recv:8890" to receive the broadcasted message.

Question 2
Go to the directory 2/ and run "make".
On client machine run "make".
Enter the IP and PORT of server in client and vice versa.

Question 3
Go to the directory 3/ and run "make".
Open a new terminal tab and run "telnet ServerIP 8890".
To run multiple clients open multiple terminal tabs and run the above command.
Enter the message after running the above command and you will receive a reversed message.
